using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class AnimationManager : MonoBehaviour
{
    PythonSimulation pythonSimulation;
    int stepIndex;
    int agentsQuantity;
    int agentDoneAnimation;
    public AgentElement agentElementPrefab;
    public float durationStep = 4.0f;
    List<AgentElement> agentsElements = new List<AgentElement>();

    public void Build(PythonSimulation pythonSimulation)
    {
        stepIndex = 0;
        this.pythonSimulation = pythonSimulation;
        agentsQuantity = pythonSimulation.agents.Length;
        agentDoneAnimation = 0;
        for (int i = 0; i < agentsQuantity; i++)
        {
            AgentElement agentElement = Instantiate(agentElementPrefab);
            agentElement.Build(this, pythonSimulation.agents[i].id);
            agentsElements.Add(agentElement);

            Step step = FindAgentStep(agentElement.id, stepIndex);
            int x = step.agentInfo.positionX;
            int y = step.agentInfo.positionY;
            int z = step.agentInfo.positionZ;

            Vector3 initialPosition = new Vector3(x, y, z);
            agentElement.transform.position = initialPosition;
        }
        NextStep();
    }

    void NextStep()
    {
        agentDoneAnimation = 0;
        foreach (AgentElement agentElement in agentsElements)
        {
            Step step = FindAgentStep(agentElement.id, stepIndex);

            int x = step.agentInfo.positionX;
            int y = step.agentInfo.positionY;
            int z = step.agentInfo.positionZ;
            Vector3 to = new Vector3(x, y, z);
            agentElement.Run(agentElement.transform.position, to, durationStep);
        }

        stepIndex += 1;
        if(stepIndex >= pythonSimulation.stepsQuantity)
        {
            stepIndex = 0;
        }
    }

    Step FindAgentStep(int agentId, int stepIndex)
    {
        Step step = null;
        step = pythonSimulation.steps.Single(s => s.agentInfo.id == agentId && s.agentInfo.stepIndex == stepIndex);
        return step;
    }

    public void DoneAgentStep(AgentElement agentElement)
    {
        agentDoneAnimation += 1;
        if(agentDoneAnimation >= agentsQuantity)
        {
            NextStep();
        }
    }
}
