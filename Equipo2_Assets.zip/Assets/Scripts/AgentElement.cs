using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AgentElement : MonoBehaviour
{
    [HideInInspector]
    public bool isAnimationDone;
    AnimationManager animationManager;
    public int id;

    public void Build(AnimationManager animationManager, int id)
    {
        this.animationManager = animationManager;
        this.id = id;
    }

    public void Run(Vector3 from, Vector3 to, float duration)
    {
        isAnimationDone = false;
        StartCoroutine(AnimateStep(from, to, duration));
    }

    void ArrivedPoint()
    {
        animationManager.DoneAgentStep(this);
    }

    IEnumerator AnimateStep(Vector3 from, Vector3 to, float duration)
    {
        float dt = 0;
        while (true)
        {
            dt += Time.deltaTime;
            float scale = dt / duration;

            transform.position = Vector3.Lerp(from, to, scale);

            if (scale >= 1)
                break;

            yield return new WaitForEndOfFrame();
        }
        isAnimationDone = true;
        ArrivedPoint();
    }
}
