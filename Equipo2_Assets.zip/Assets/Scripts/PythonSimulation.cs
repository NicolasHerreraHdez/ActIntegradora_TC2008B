﻿using System;

public class PythonSimulation
{
    public Agent[] agents;
    public int stepsQuantity;
    public Step[] steps;
}

[Serializable]
public class Step
{
    public AgentInfo agentInfo;
}

[Serializable]
public class Agent
{
    public int id;
}

[Serializable]
public class AgentInfo
{
    public int id;
    public int stepIndex;
    public int positionX;
    public int positionY;
    public int positionZ;
}
