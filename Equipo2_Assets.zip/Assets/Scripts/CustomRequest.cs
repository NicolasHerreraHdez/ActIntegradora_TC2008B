using UnityEngine;
using UnityEngine.Networking;
using System.Collections;

public class CustomRequest : MonoBehaviour
{
    public string uri = "";//https://jsonplaceholder.typicode.com/posts/2
    public AnimationManager animationManager;

    void Start()
    {
        StartCoroutine(GetRequest(uri));
    }

    IEnumerator GetRequest(string uri)
    {
        using (UnityWebRequest webRequest = UnityWebRequest.Get(uri))
        {
            // Request and wait for the desired page.
            yield return webRequest.SendWebRequest();

            string[] pages = uri.Split('/');
            int page = pages.Length - 1;

            switch (webRequest.result)
            {
                case UnityWebRequest.Result.ConnectionError:
                case UnityWebRequest.Result.DataProcessingError:
                    Debug.LogError(pages[page] + ": Error: " + webRequest.error);
                    break;
                case UnityWebRequest.Result.ProtocolError:
                    Debug.LogError(pages[page] + ": HTTP Error: " + webRequest.error);
                    break;
                case UnityWebRequest.Result.Success:
                    string jsonText = webRequest.downloadHandler.text;
                    PythonSimulation pSimulation = JsonUtility.FromJson<PythonSimulation>(jsonText);
                    animationManager.Build(pSimulation);
                    break;
            }
        }
    }

    public class MuckUpJson
    {
        public static string jsonText = "{\"elements\":[{\"info\":{\"agentId\":1,\"positionX\":3,\"positionY\":0,\"positionZ\":5}},{\"info\":{\"agentId\":1,\"positionX\":3,\"positionY\":0,\"positionZ\":5}},{\"info\":{\"agentId\":1,\"positionX\":3,\"positionY\":0,\"positionZ\":5}}]}";
    }
}
